import  detect

def run():
    opt = detect.myoption()
    detect.main(opt)